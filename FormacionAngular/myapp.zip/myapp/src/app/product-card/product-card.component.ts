import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UpperCasePipe } from '@angular/common';
import { DatePipe } from '@angular/common';
import { CurrencyPipe } from '@angular/common';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [FormsModule, UpperCasePipe, DatePipe, CurrencyPipe],
  templateUrl: './product-card.component.html',
  styleUrl: './product-card.component.scss'
})
export class ProductCardComponent {
  product = {
  image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAt-vKjEyv-NOUVTIa69ved-Gs83uwLlu-ifGtFSnscQ&s=10',
  name: 'Rustic Metal Car' ,
  description: 'The slim & simple Maple Gaming Keyboard from Dev Byte comes with a sleek body and 7- Color RGB LED Back-lighting for smart functionality',
  unitAvailable:20,
  date: 'Sun May 10 2026 02:35:46 GMT+0200 (Central European Summer Time)',
  price:34.5645645
  }
  productImageStyle={
    border:'1px solid black',
    filter: 'sepia(0)'
  }
  
  formState=false
  
  address= ''
  postalCode = 0
  
  orderProduct(){
    console.log(`Dirección de usuario: ${this.address}`)
    console.log(`Código postal: ${this.postalCode}`)
  }

  buyProduct(){
    console.log('compraremos un producto')
    this.formState=true
  }

   addToCar(){
    console.log('agregamos un producto al carro de compras')
  }

  onMouseEnter(){
    console.log('mouse enter')
    this.productImageStyle={...this.productImageStyle,filter: 'sepia(0.3)'}
  }

  onMouseLeave(){
    console.log('mouse leave')
    this.productImageStyle={...this.productImageStyle,filter: 'sepia(0)'}
  }
}
